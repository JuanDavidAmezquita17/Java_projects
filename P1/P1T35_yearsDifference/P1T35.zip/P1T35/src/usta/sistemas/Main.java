package usta.sistemas;

import java.util.Scanner ;
public class Main {

    public static void main(String[] args) {
	/*Author: Juan David Amezquita Nuñez
	 *Date: 12/03/2020
	 * Description: This program that receives two years of birth and print the difference.
	 */
	Scanner keyboard = new Scanner(System.in);
	int B1, B2, difference ;

        System.out.println("This software receives two years of birth and print the difference, Input the first year: ");
         B1 = keyboard.nextInt():
        System.out.println("Input the second year: ");
         B2 = keyboard.nextInt():

        difference = B1 - B2 ;
        System.out.println("The difference of the first year, and the second year is: " + difference);

    }
}





