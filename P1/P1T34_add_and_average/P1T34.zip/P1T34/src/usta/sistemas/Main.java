package usta.sistemas;

import java.util.Scanner ;
public class Main {

    public static void main(String[] args) {
	/*Author: Juan David Amézquita Núñez
	 *Date: 12/03/2020
	 * Description: this software add three variable and find the average the three variable
	 */
	Scanner keyboard = new Scanner(System.in);
	int v1, v2, v3, suma, average ;
        System.out.println("This software add three numbers, and then, it find the average, Input the first variable");
         v1 = keyboard.nextInt ();
        System.out.println("Input the second variable");
         v2 = keyboard.nextInt ();
        System.out.println("Input the third variable");
         v3 = keyboard.nextInt ();

        suma = v1 + v2 + v3 ;
        average = suma/3 ;
        System.out.println("The result of the add is: " + suma);
        System.out.println("The result of the average is: " + average);
        System.out.println("Thanks for use this software, Created by Juan David Amezquita Nuñez");


    }
}
